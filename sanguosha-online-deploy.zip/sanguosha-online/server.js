const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));
const rooms = new Map();

function code() {
  let value;
  do { value = String(Math.floor(100000 + Math.random() * 900000)); }
  while (rooms.has(value));
  return value;
}
function publicRoom(room) {
  return {
    code: room.code,
    players: room.players.map(p => ({ name: p.name, ready: p.ready })),
    started: room.started,
    turn: room.turn
  };
}
function update(room) {
  room.players.forEach(p => io.to(p.id).emit("room:update", publicRoom(room)));
}
function leave(socket) {
  const code = socket.data.roomCode;
  if (!code) return;
  const room = rooms.get(code);
  socket.data.roomCode = null;
  if (!room) return;
  room.players = room.players.filter(p => p.id !== socket.id);
  if (room.players.length === 0) rooms.delete(code);
  else {
    room.started = false;
    room.players.forEach(p => p.ready = false);
    update(room);
    room.players.forEach(p => io.to(p.id).emit("notice", "对方已离开房间。"));
  }
}

io.on("connection", socket => {
  socket.on("room:create", ({ name }) => {
    leave(socket);
    const roomCode = code();
    const room = { code: roomCode, players: [{ id: socket.id, name: cleanName(name), ready: false }], started: false, turn: 0 };
    rooms.set(roomCode, room);
    socket.data.roomCode = roomCode;
    socket.emit("room:created", roomCode);
    update(room);
  });

  socket.on("room:join", ({ code: input, name }) => {
    leave(socket);
    const room = rooms.get(String(input || "").trim());
    if (!room) return socket.emit("error:message", "找不到这个房间，请检查六位房间码。");
    if (room.players.length >= 2) return socket.emit("error:message", "房间已经有两名玩家，不能加入第三人。");
    if (room.started) return socket.emit("error:message", "游戏已经开始，不能加入。");
    room.players.push({ id: socket.id, name: cleanName(name), ready: false });
    socket.data.roomCode = room.code;
    update(room);
  });

  socket.on("player:ready", ready => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || room.players.length !== 2 || room.started) return;
    const player = room.players.find(p => p.id === socket.id);
    if (player) player.ready = Boolean(ready);
    update(room);
    if (room.players.length === 2 && room.players.every(p => p.ready)) {
      room.started = true;
      room.turn = Math.floor(Math.random() * 2);
      update(room);
      room.players.forEach((p, i) => io.to(p.id).emit("game:start", {
        message: "两名真人玩家都已准备，游戏开始！",
        yourTurn: i === room.turn
      }));
    }
  });

  socket.on("game:endTurn", () => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || !room.started) return;
    if (room.players[room.turn]?.id !== socket.id) return socket.emit("notice", "现在还不是你的回合。");
    room.turn = 1 - room.turn;
    room.players.forEach((p, i) => io.to(p.id).emit("turn:update", { yourTurn: i === room.turn }));
  });

  socket.on("disconnect", () => leave(socket));
});

function cleanName(value) {
  return String(value || "玩家").trim().slice(0, 12) || "玩家";
}

server.listen(PORT, "0.0.0.0", () => console.log(`Server listening on ${PORT}`));
