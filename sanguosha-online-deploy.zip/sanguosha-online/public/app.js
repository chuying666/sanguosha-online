const socket = io();
const $ = id => document.getElementById(id);
let isReady = false;

function name() { return $("name").value.trim() || "玩家"; }
function message(text) { $("message").textContent = text; }

$("create").onclick = () => socket.emit("room:create", { name: name() });
$("join").onclick = () => socket.emit("room:join", { code: $("roomCode").value, name: name() });
$("ready").onclick = () => {
  isReady = !isReady;
  socket.emit("player:ready", isReady);
  $("ready").textContent = isReady ? "取消准备" : "准备";
};
$("endTurn").onclick = () => socket.emit("game:endTurn");

socket.on("room:created", code => {
  $("room").classList.remove("hidden");
  $("code").textContent = code;
  message("房间创建成功！把六位房间码发给朋友。");
});
socket.on("room:update", room => {
  $("room").classList.remove("hidden");
  $("code").textContent = room.code;
  $("players").innerHTML = "";
  room.players.forEach(p => {
    const li = document.createElement("li");
    li.textContent = `${p.name} — ${p.ready ? "已准备" : "未准备"}`;
    $("players").appendChild(li);
  });
  $("status").textContent = room.players.length === 1 ? "等待朋友加入（还差 1 人）" : "两名玩家已进入房间";
  $("ready").disabled = room.players.length !== 2 || room.started;
  if (room.started) $("game").classList.remove("hidden");
});
socket.on("game:start", data => {
  $("game").classList.remove("hidden");
  $("turn").textContent = data.yourTurn ? "随机先手：现在轮到你！" : "随机先手：现在轮到朋友。";
  message(data.message);
});
socket.on("turn:update", data => {
  $("turn").textContent = data.yourTurn ? "轮到你了！" : "轮到朋友了。";
});
socket.on("notice", message);
socket.on("error:message", message);
socket.on("connect", () => message("已连接服务器。"));
socket.on("disconnect", () => message("连接中断，正在尝试重新连接……"));
